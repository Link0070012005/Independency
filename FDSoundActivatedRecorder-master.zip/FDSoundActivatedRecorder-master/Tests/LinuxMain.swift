import XCTest
@testable import FDSoundActivatedRecorderTests

var tests = [XCTestCaseEntry]()
tests += FDSoundActivatedRecorderTests.allTests()
XCTMain(tests)
